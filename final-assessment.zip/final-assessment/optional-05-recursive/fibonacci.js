function fibonacci(n) {

}

// Jangan hapus kode di bawah ini!
export default fibonacci;
